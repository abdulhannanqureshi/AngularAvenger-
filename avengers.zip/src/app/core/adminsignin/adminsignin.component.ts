import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminsignin',
  templateUrl: './adminsignin.component.html',
  styleUrls: ['./adminsignin.component.css']
})
export class AdminsigninComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
